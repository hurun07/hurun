<?php
session_start();
require_once 'config.php';

// Check if user is logged in and is admin
if (!isset($_SESSION['loggedin']) || $_SESSION['role'] !== 'admin') {
    header('Location: index.php');
    exit;
}

// Initialize variables with default values
$start_date = $_GET['start_date'] ?? date('Y-m-01');
$end_date = $_GET['end_date'] ?? date('Y-m-d');
$produk_id = $_GET['produk_id'] ?? '';
$error = '';
$produk_list = [];
$laporan_transaksi = [];
$total_transaksi = 0;
$total_pendapatan = 0;
$total_produk = 0;

// Get product list for filter
try {
    $stmt = $conn->query("SELECT id, nama FROM produk ORDER BY nama");
    $produk_list = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch(PDOException $e) {
    $error = "Gagal mengambil data produk: " . $e->getMessage();
}

// Get transaction report data
try {
    // Base query
    $query = "SELECT 
                t.id,
                t.tanggal,
                t.total,
                GROUP_CONCAT(p.nama SEPARATOR ', ') as produk,
                SUM(td.jumlah) as jumlah_produk
              FROM transaksi t
              JOIN transaksi_detail td ON t.id = td.transaksi_id
              JOIN produk p ON td.produk_id = p.id";
    
    // WHERE conditions
    $conditions = [];
    $params = [];
    
    // Date filter
    if (!empty($start_date) && !empty($end_date)) {
        $conditions[] = "DATE(t.tanggal) BETWEEN :start_date AND :end_date";
        $params[':start_date'] = $start_date;
        $params[':end_date'] = $end_date;
    }
    
    // Product filter
    if (!empty($produk_id)) {
        $conditions[] = "td.produk_id = :produk_id";
        $params[':produk_id'] = $produk_id;
    }
    
    // Combine conditions if any
    if (!empty($conditions)) {
        $query .= " WHERE " . implode(" AND ", $conditions);
    }
    
    // Group and order
    $query .= " GROUP BY t.id ORDER BY t.tanggal DESC";
    
    // Execute query
    $stmt = $conn->prepare($query);
    $stmt->execute($params);
    $laporan_transaksi = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    // Get summary data
    $query_total = "SELECT 
                      COUNT(DISTINCT t.id) as total_transaksi,
                      SUM(t.total) as total_pendapatan,
                      SUM(td.jumlah) as total_produk
                    FROM transaksi t
                    JOIN transaksi_detail td ON t.id = td.transaksi_id";
    
    // Combine conditions if any
    if (!empty($conditions)) {
        $query_total .= " WHERE " . implode(" AND ", $conditions);
    }
    
    $stmt_total = $conn->prepare($query_total);
    $stmt_total->execute($params);
    $total_data = $stmt_total->fetch(PDO::FETCH_ASSOC);
    
    $total_transaksi = $total_data['total_transaksi'] ?? 0;
    $total_pendapatan = $total_data['total_pendapatan'] ?? 0;
    $total_produk = $total_data['total_produk'] ?? 0;

} catch(PDOException $e) {
    $error = "Gagal mengambil data laporan: " . $e->getMessage();
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Laporan Transaksi - Kasir Toko Bangunan</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.0/font/bootstrap-icons.css">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600&display=swap" rel="stylesheet">
    <style>
        :root {
            --primary-color: #4361ee;
            --secondary-color: #3f37c9;
            --success-color: #4cc9f0;
            --danger-color: #f72585;
            --warning-color: #f8961e;
            --info-color: #4895ef;
            --dark-color: #212529;
            --light-color: #f8f9fa;
            --sidebar-width: 250px;
        }
        
        body {
            font-family: 'Poppins', sans-serif;
            background-color: #f5f7fa;
            color: #333;
        }
        
         .sidebar {
            min-height: 100vh;
            width: var(--sidebar-width);
            background: linear-gradient(180deg, var(--primary-color), var(--secondary-color));
            position: fixed;
            box-shadow: 0 0 20px rgba(0, 0, 0, 0.1);
            z-index: 1000;
        }
        
        .sidebar-brand {
            padding: 1.5rem 1rem;
            color: white;
            text-align: center;
            border-bottom: 1px solid rgba(255, 255, 255, 0.1);
        }
        
        .sidebar-user {
            text-align: center;
            padding: 1rem;
            color: white;
            border-bottom: 1px solid rgba(255, 255, 255, 0.1);
        }

        
        .sidebar-user .badge {
            background-color: rgba(255, 255, 255, 0.2);
            font-weight: 400;
            text-transform: capitalize;
        }

        .nav-link {
            color: rgba(255, 255, 255, 0.8);
            padding: 0.75rem 1.5rem;
            margin: 0.25rem 1rem;
            border-radius: 8px;
            transition: all 0.3s;
            font-weight: 500;
        }
        
        .nav-link:hover, .nav-link.active {
            color: white;
            background-color: rgba(255, 255, 255, 0.15);
            transform: translateX(5px);
        }
        
        .nav-link.active {
            background-color: rgba(255, 255, 255, 0.25);
            font-weight: 600;
        }
        
        .main-content {
            margin-left: var(--sidebar-width);
            padding: 2rem;
            min-height: 100vh;
        }
        
        .header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 2rem;
            padding-bottom: 1rem;
            border-bottom: 1px solid #e0e0e0;
        }
        
        .stat-card {
            color: white;
            border-radius: 12px;
            overflow: hidden;
            position: relative;
            z-index: 1;
        }
        
        .stat-card::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: linear-gradient(135deg, rgba(255,255,255,0.1), rgba(255,255,255,0));
            z-index: -1;
        }
        
        .stat-card .card-body {
            padding: 1.5rem;
        }
        
        .stat-card .card-title {
            font-size: 1rem;
            font-weight: 500;
            opacity: 0.9;
            margin-bottom: 0.5rem;
        }
        
        .stat-card .card-value {
            font-size: 1.75rem;
            font-weight: 600;
            margin-bottom: 0.5rem;
        }
        
        .stat-card .card-icon {
            font-size: 2.5rem;
            opacity: 0.2;
            position: absolute;
            right: 1.5rem;
            top: 1.5rem;
        }
        
        .filter-card {
            border-radius: 12px;
            box-shadow: 0 4px 20px rgba(0, 0, 0, 0.05);
        }
        
        .table-responsive {
            overflow-x: auto;
        }
        
        .table thead th {
            background-color: #f8f9fa;
            border-top: 1px solid #e0e0e0;
            border-bottom: 1px solid #e0e0e0;
            font-weight: 600;
            padding: 1rem;
        }
        
        .table tbody td {
            padding: 1rem;
            vertical-align: middle;
            border-bottom: 1px solid #e0e0e0;
        }
        
        .table tbody tr:last-child td {
            border-bottom: none;
        }
        
        @media (max-width: 992px) {
            .sidebar {
                width: 80px;
                overflow: hidden;
            }
            
            .sidebar-brand, .sidebar-user, .nav-link span {
                display: none;
            }
            
            .nav-link {
                text-align: center;
                margin: 0.25rem 0.5rem;
                padding: 0.75rem 0;
            }
            
            .nav-link i {
                margin-right: 0;
                font-size: 1.25rem;
            }
            
            .main-content {
                margin-left: 80px;
            }
        }
           
        .nav-link i {
            width: 24px;
            text-align: center;
            margin-right: 10px;
        }
    </style>
</head>
<body>
    <div class="d-flex">
        <!-- Sidebar -->
        <div class="sidebar">
            <div class="sidebar-brand">
                <h4>Toko Bangunan</h4>
                <div class="text-muted">Point of Sale</div>
            </div>
            
            <div class="sidebar-user">
                <div class="mb-2">
                    <i class="bi bi-person-circle fs-3"></i>
                </div>
                <h6><?php echo htmlspecialchars($_SESSION['nama'] ?? 'User'); ?></h6>
                <span class="badge"><?php echo htmlspecialchars($_SESSION['role'] ?? 'role'); ?></span>
            </div>
            
            <ul class="nav flex-column mt-3">
                <li class="nav-item">
                    <a class="nav-link" href="index.php">
                        <i class="bi bi-speedometer2"></i>
                        <span>Dashboard</span>
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="transaksi.php">
                        <i class="bi bi-cart"></i>
                        <span>Transaksi</span>
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="produk.php">
                        <i class="bi bi-box-seam"></i>
                        <span>Produk</span>
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link active" href="laporan.php">
                        <i class="bi bi-file-earmark-text"></i>
                        <span>Laporan</span>
                    </a>
                </li>
                <li class="nav-item mt-4">
                    <a class="nav-link" href="logout.php">
                        <i class="bi bi-box-arrow-right"></i>
                        <span>Logout</span>
                    </a>
                </li>
            </ul>
        </div>

        <!-- Main Content -->
        <div class="main-content">
            <div class="header">
                <h2>Laporan Transaksi</h2>
                <div class="date-info">
                    <i class="bi bi-calendar me-2"></i>
                    <?php echo date('l, d F Y'); ?>
                </div>
            </div>

            <?php if ($error): ?>
            <div class="alert alert-danger alert-dismissible fade show">
                <i class="bi bi-exclamation-circle me-2"></i>
                <?php echo htmlspecialchars($error); ?>
                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>
            <?php endif; ?>

            <!-- Filter Form -->
            <div class="card mb-4 filter-card">
                <div class="card-header bg-white">
                    <h5 class="mb-0"><i class="bi bi-funnel me-2"></i>Filter Laporan</h5>
                </div>
                <div class="card-body">
                    <form method="get" action="laporan.php">
                        <div class="row g-3">
                            <div class="col-md-3">
                                <label for="start_date" class="form-label">Tanggal Mulai</label>
                                <input type="date" class="form-control" id="start_date" name="start_date" 
                                    value="<?php echo htmlspecialchars($start_date); ?>" max="<?php echo date('Y-m-d'); ?>">
                            </div>
                            <div class="col-md-3">
                                <label for="end_date" class="form-label">Tanggal Akhir</label>
                                <input type="date" class="form-control" id="end_date" name="end_date" 
                                    value="<?php echo htmlspecialchars($end_date); ?>" max="<?php echo date('Y-m-d'); ?>">
                            </div>
                            <div class="col-md-4">
                                <label for="produk_id" class="form-label">Produk</label>
                                <select class="form-select" id="produk_id" name="produk_id">
                                    <option value="">Semua Produk</option>
                                    <?php foreach ($produk_list as $produk): ?>
                                        <option value="<?php echo $produk['id']; ?>" 
                                            <?php echo $produk_id == $produk['id'] ? 'selected' : ''; ?>>
                                            <?php echo htmlspecialchars($produk['nama']); ?>
                                        </option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                            <div class="col-md-2 d-flex align-items-end">
                                <button type="submit" class="btn btn-primary w-100">
                                    <i class="bi bi-funnel me-1"></i> Filter
                                </button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>

            <!-- Summary Cards -->
            <div class="row mb-4 g-4">
                <div class="col-md-4">
                    <div class="stat-card" style="background-color: var(--primary-color);">
                        <div class="card-body">
                            <h5 class="card-title">Total Transaksi</h5>
                            <div class="card-value"><?php echo number_format($total_transaksi, 0, ',', '.'); ?></div>
                            <small>Periode <?php echo date('d M Y', strtotime($start_date)); ?> - <?php echo date('d M Y', strtotime($end_date)); ?></small>
                            <i class="bi bi-receipt card-icon"></i>
                        </div>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="stat-card" style="background-color: var(--success-color);">
                        <div class="card-body">
                            <h5 class="card-title">Total Pendapatan</h5>
                            <div class="card-value">Rp <?php echo number_format($total_pendapatan, 0, ',', '.'); ?></div>
                            <small>Periode <?php echo date('d M Y', strtotime($start_date)); ?> - <?php echo date('d M Y', strtotime($end_date)); ?></small>
                            <i class="bi bi-cash-stack card-icon"></i>
                        </div>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="stat-card" style="background-color: var(--info-color);">
                        <div class="card-body">
                            <h5 class="card-title">Total Produk Terjual</h5>
                            <div class="card-value"><?php echo number_format($total_produk, 0, ',', '.'); ?></div>
                            <small>Periode <?php echo date('d M Y', strtotime($start_date)); ?> - <?php echo date('d M Y', strtotime($end_date)); ?></small>
                            <i class="bi bi-box-seam card-icon"></i>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Transaction Report Table -->
            <div class="card border-0 shadow-sm">
                <div class="card-header bg-white d-flex justify-content-between align-items-center">
                    <h5 class="mb-0"><i class="bi bi-table me-2"></i>Detail Transaksi</h5>
                    <div>
                        <a href="export_laporan.php?start_date=<?php echo $start_date; ?>&end_date=<?php echo $end_date; ?>&produk_id=<?php echo $produk_id; ?>" 
                           class="btn btn-success btn-sm">
                            <i class="bi bi-file-excel me-1"></i> Export Excel
                        </a>
                        <button class="btn btn-primary btn-sm ms-2" onclick="window.print()">
                            <i class="bi bi-printer me-1"></i> Cetak
                        </button>
                    </div>
                </div>
                <div class="card-body">
                    <div class="table-responsive">
                        <table class="table table-hover">
                            <thead class="table-light">
                                <tr>
                                    <th>No. Transaksi</th>
                                    <th>Tanggal</th>
                                    <th>Total</th>
                                    <th>Jumlah Produk</th>
                                    <th>Produk</th>
                                    <th class="text-end">Aksi</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php if (!empty($laporan_transaksi)): ?>
                                    <?php foreach ($laporan_transaksi as $transaksi): ?>
                                        <tr>
                                            <td>
                                                <span class="badge bg-light text-dark">TRX-<?php echo str_pad($transaksi['id'], 5, '0', STR_PAD_LEFT); ?></span>
                                            </td>
                                            <td><?php echo date('d/m/Y H:i', strtotime($transaksi['tanggal'])); ?></td>
                                            <td class="fw-bold">Rp <?php echo number_format($transaksi['total'], 0, ',', '.'); ?></td>
                                            <td><?php echo $transaksi['jumlah_produk']; ?></td>
                                            <td class="text-truncate" style="max-width: 200px;" title="<?php echo htmlspecialchars($transaksi['produk']); ?>">
                                                <?php echo htmlspecialchars($transaksi['produk']); ?>
                                            </td>
                                            <td class="text-end">
                                                <a href="detail_transaksi.php?id=<?php echo $transaksi['id']; ?>" class="btn btn-sm btn-outline-primary">
                                                    <i class="bi bi-eye me-1"></i> Detail
                                                </a>
                                            </td>
                                        </tr>
                                    <?php endforeach; ?>
                                <?php else: ?>
                                    <tr>
                                        <td colspan="6" class="text-center py-4">
                                            <i class="bi bi-exclamation-circle fs-4 text-muted"></i>
                                            <p class="mt-2 mb-0">Tidak ada data transaksi</p>
                                        </td>
                                    </tr>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        // Set end date to be >= start date
        document.getElementById('start_date').addEventListener('change', function() {
            const endDate = document.getElementById('end_date');
            if (this.value > endDate.value) {
                endDate.value = this.value;
            }
            endDate.min = this.value;
        });
        
        // Set max date to today
        document.addEventListener('DOMContentLoaded', function() {
            const today = new Date().toISOString().split('T')[0];
            document.getElementById('start_date').max = today;
            document.getElementById('end_date').max = today;
        });
    </script>
</body>
</html>