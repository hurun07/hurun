<?php
session_start();
require_once 'config.php';

// Cek apakah user sudah login
if (!isset($_SESSION['loggedin']) || $_SESSION['loggedin'] !== true) {
    header('Location: login.php');
    exit;
}

// Ambil parameter filter
$start_date = isset($_GET['start_date']) ? $_GET['start_date'] : date('Y-m-01');
$end_date = isset($_GET['end_date']) ? $_GET['end_date'] : date('Y-m-d');
$produk_id = isset($_GET['produk_id']) ? $_GET['produk_id'] : '';

// Query untuk laporan transaksi
try {
    // Query dasar
    $query = "SELECT 
                t.id,
                t.tanggal,
                t.total,
                GROUP_CONCAT(p.nama SEPARATOR ', ') as produk,
                SUM(td.jumlah) as jumlah_produk
              FROM transaksi t
              JOIN transaksi_detail td ON t.id = td.transaksi_id
              JOIN produk p ON td.produk_id = p.id";
    
    // Kondisi WHERE
    $conditions = [];
    $params = [];
    
    // Filter tanggal
    if (!empty($start_date) && !empty($end_date)) {
        $conditions[] = "DATE(t.tanggal) BETWEEN :start_date AND :end_date";
        $params[':start_date'] = $start_date;
        $params[':end_date'] = $end_date;
    }
    
    // Filter produk
    if (!empty($produk_id)) {
        $conditions[] = "td.produk_id = :produk_id";
        $params[':produk_id'] = $produk_id;
    }
    
    // Gabungkan kondisi WHERE jika ada
    if (!empty($conditions)) {
        $query .= " WHERE " . implode(" AND ", $conditions);
    }
    
    // Group by dan order by
    $query .= " GROUP BY t.id ORDER BY t.tanggal DESC";
    
    // Eksekusi query
    $stmt = $conn->prepare($query);
    $stmt->execute($params);
    $laporan_transaksi = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    // Query untuk total
    $query_total = "SELECT 
                      COUNT(DISTINCT t.id) as total_transaksi,
                      SUM(t.total) as total_pendapatan,
                      SUM(td.jumlah) as total_produk
                    FROM transaksi t
                    JOIN transaksi_detail td ON t.id = td.transaksi_id";
    
    if (!empty($conditions)) {
        $query_total .= " WHERE " . implode(" AND ", $conditions);
    }
    
    $stmt_total = $conn->prepare($query_total);
    $stmt_total->execute($params);
    $total_data = $stmt_total->fetch(PDO::FETCH_ASSOC);

    // Header untuk file Excel
    header('Content-Type: application/vnd.ms-excel');
    header('Content-Disposition: attachment; filename="laporan_transaksi_'.date('YmdHis').'.xls"');
    
    // Output Excel
    echo '<html>';
    echo '<head><meta charset="UTF-8"></head>';
    echo '<body>';
    echo '<table border="1">';
    
    // Header Laporan
    echo '<tr><th colspan="6" style="text-align:center;background:#f2f2f2;font-size:16px;">LAPORAN TRANSAKSI</th></tr>';
    echo '<tr><th colspan="6" style="text-align:center;background:#f2f2f2;">Periode: '.date('d/m/Y', strtotime($start_date)).' - '.date('d/m/Y', strtotime($end_date)).'</th></tr>';
    
    // Summary
    echo '<tr><th colspan="6" style="background:#e6e6e6;">SUMMARY</th></tr>';
    echo '<tr>';
    echo '<th style="background:#f2f2f2;">Total Transaksi</th>';
    echo '<td>'.number_format($total_data['total_transaksi'], 0, ',', '.').'</td>';
    echo '<th style="background:#f2f2f2;">Total Pendapatan</th>';
    echo '<td>Rp '.number_format($total_data['total_pendapatan'], 0, ',', '.').'</td>';
    echo '<th style="background:#f2f2f2;">Total Produk Terjual</th>';
    echo '<td>'.number_format($total_data['total_produk'], 0, ',', '.').'</td>';
    echo '</tr>';
    
    // Header Tabel
    echo '<tr><th colspan="6" style="background:#e6e6e6;">DETAIL TRANSAKSI</th></tr>';
    echo '<tr style="background:#f2f2f2;">';
    echo '<th>No. Transaksi</th>';
    echo '<th>Tanggal</th>';
    echo '<th>Total</th>';
    echo '<th>Jumlah Produk</th>';
    echo '<th>Produk</th>';
    echo '</tr>';
    
    // Data Transaksi
    foreach ($laporan_transaksi as $transaksi) {
        echo '<tr>';
        echo '<td>TRX-'.str_pad($transaksi['id'], 5, '0', STR_PAD_LEFT).'</td>';
        echo '<td>'.date('d/m/Y H:i', strtotime($transaksi['tanggal'])).'</td>';
        echo '<td>Rp '.number_format($transaksi['total'], 0, ',', '.').'</td>';
        echo '<td>'.$transaksi['jumlah_produk'].'</td>';
        echo '<td>'.htmlspecialchars($transaksi['produk']).'</td>';
        echo '</tr>';
    }
    
    echo '</table>';
    echo '</body>';
    echo '</html>';

} catch(PDOException $e) {
    $_SESSION['error'] = "Gagal mengekspor data: " . $e->getMessage();
    header('Location: laporan.php');
    exit;
}
?>