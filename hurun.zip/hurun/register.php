<?php
session_start();

// Jika sudah login, redirect ke index
if (isset($_SESSION['loggedin'])) {
    header('Location: index.php');
    exit;
}

require_once 'config.php';

$error = '';
$success = '';

// Proses registrasi
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $nama = trim($_POST['nama']);
    $username = trim($_POST['username']);
    $password = $_POST['password'];
    $confirm_password = $_POST['confirm_password'];

    // Validasi input
    if (empty($nama) || empty($username) || empty($password)) {
        $error = 'Semua field harus diisi!';
    } elseif ($password !== $confirm_password) {
        $error = 'Password tidak cocok!';
    } elseif (strlen($password) < 6) {
        $error = 'Password minimal 6 karakter!';
    } else {
        try {
            // Cek apakah username sudah ada
            $check_query = "SELECT id FROM user WHERE username = :username";
            $check_stmt = $conn->prepare($check_query);
            $check_stmt->bindParam(':username', $username);
            $check_stmt->execute();

            if ($check_stmt->rowCount() > 0) {
                $error = 'Username sudah digunakan!';
            } else {
                // Hash password
                $hashed_password = password_hash($password, PASSWORD_DEFAULT);
                $role = 'kasir'; // Default role untuk user baru

                // Insert user baru
                $insert_query = "INSERT INTO user (username, password, nama, role) 
                                VALUES (:username, :password, :nama, :role)";
                $insert_stmt = $conn->prepare($insert_query);
                $insert_stmt->bindParam(':username', $username);
                $insert_stmt->bindParam(':password', $hashed_password);
                $insert_stmt->bindParam(':nama', $nama);
                $insert_stmt->bindParam(':role', $role);

                if ($insert_stmt->execute()) {
                    $success = 'Registrasi berhasil! Silakan login.';
                    // Kosongkan form setelah registrasi berhasil
                    $_POST = array();
                } else {
                    $error = 'Terjadi kesalahan saat registrasi. Silakan coba lagi.';
                }
            }
        } catch(PDOException $e) {
            $error = 'Terjadi kesalahan sistem: ' . $e->getMessage();
        }
    }
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Register - Kasir Toko Bangunan</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body {
            background-color: #f8f9fa;
            height: 100vh;
            display: flex;
            align-items: center;
            background-image: linear-gradient(135deg, #f5f7fa 0%, #c3cfe2 100%);
        }
        .register-container {
            max-width: 450px;
            width: 100%;
            padding: 30px;
            background: white;
            border-radius: 10px;
            box-shadow: 0 0 20px rgba(0, 0, 0, 0.1);
        }
        .register-header {
            text-align: center;
            margin-bottom: 30px;
        }
        .register-header img {
            width: 80px;
            margin-bottom: 15px;
        }
        .register-header h2 {
            color: #333;
            font-weight: 600;
        }
        .form-control {
            height: 45px;
            border-radius: 5px;
        }
        .btn-register {
            background-color: #4e73df;
            border: none;
            height: 45px;
            font-weight: 600;
            width: 100%;
        }
        .btn-register:hover {
            background-color: #2e59d9;
        }
        .error-message {
            color: #e74a3b;
            font-size: 14px;
            margin-top: 5px;
        }
        .success-message {
            color: #1cc88a;
            font-size: 14px;
            margin-top: 5px;
        }
        .login-link {
            text-align: center;
            margin-top: 15px;
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="row justify-content-center">
            <div class="register-container">
                <div class="register-header">
                    <img src="https://cdn-icons-png.flaticon.com/512/3713/3713546.png" alt="Toko Bangunan">
                    <h2>Registrasi Akun</h2>
                    <p class="text-muted">Toko Bangunan Maju Jaya</p>
                </div>

                <?php if ($error): ?>
                    <div class="alert alert-danger"><?php echo $error; ?></div>
                <?php endif; ?>
                
                <?php if ($success): ?>
                    <div class="alert alert-success"><?php echo $success; ?></div>
                <?php endif; ?>

                <form action="register.php" method="POST">
                    <div class="mb-3">
                        <label for="nama" class="form-label">Nama Lengkap</label>
                        <input type="text" class="form-control" id="nama" name="nama" required 
                               placeholder="Masukkan nama lengkap" value="<?php echo htmlspecialchars($_POST['nama'] ?? ''); ?>" autofocus>
                    </div>
                    <div class="mb-3">
                        <label for="username" class="form-label">Username</label>
                        <input type="text" class="form-control" id="username" name="username" required 
                               placeholder="Masukkan username" value="<?php echo htmlspecialchars($_POST['username'] ?? ''); ?>">
                    </div>
                    <div class="mb-3">
                        <label for="password" class="form-label">Password</label>
                        <input type="password" class="form-control" id="password" name="password" required 
                               placeholder="Masukkan password (minimal 6 karakter)">
                    </div>
                    <div class="mb-3">
                        <label for="confirm_password" class="form-label">Konfirmasi Password</label>
                        <input type="password" class="form-control" id="confirm_password" name="confirm_password" required 
                               placeholder="Masukkan password kembali">
                    </div>
                    <div class="d-grid gap-2 mb-3">
                        <button type="submit" class="btn btn-primary btn-register">Daftar</button>
                    </div>
                    <div class="login-link">
                        <p>Sudah punya akun? <a href="login.php">Login disini</a></p>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>