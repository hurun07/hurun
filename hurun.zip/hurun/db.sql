-- Buat database
CREATE DATABASE IF NOT EXISTS kasir_toko_bangunan;
USE kasir_toko_bangunan;

-- 1. Tabel user (untuk login)
CREATE TABLE user (
    id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(50) NOT NULL UNIQUE,
    password VARCHAR(255) NOT NULL,
    nama VARCHAR(100) NOT NULL,
    role ENUM('admin', 'kasir') NOT NULL DEFAULT 'kasir'
);

-- 2. Tabel produk
CREATE TABLE produk (
    id INT AUTO_INCREMENT PRIMARY KEY,
    kode VARCHAR(20) NOT NULL UNIQUE,
    nama VARCHAR(100) NOT NULL,
    harga INT NOT NULL,
    stok INT NOT NULL DEFAULT 0
);

-- 3. Tabel transaksi
CREATE TABLE transaksi (
    id INT AUTO_INCREMENT PRIMARY KEY,
    tanggal DATETIME DEFAULT CURRENT_TIMESTAMP,
    total INT NOT NULL,
    bayar INT NOT NULL,
    kembali INT NOT NULL
);

-- 4. Tabel transaksi_detail
CREATE TABLE transaksi_detail (
    id INT AUTO_INCREMENT PRIMARY KEY,
    transaksi_id INT NOT NULL,
    produk_id INT NOT NULL,
    jumlah INT NOT NULL,
    harga INT NOT NULL,
    subtotal INT NOT NULL
);


-- Contoh produk
INSERT INTO produk (kode, nama, harga, stok) VALUES
('PRD001', 'Semen Tiga Roda 50kg', 75000, 100),
('PRD002', 'Paku Beton 3 inch', 25000, 200),
('PRD003', 'Cat Tembok Putih', 180000, 50),
('PRD004', 'Keramik 40x40', 65000, 80),
('PRD005', 'Besi Beton 8mm', 95000, 60);