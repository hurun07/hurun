    <?php
    session_start();

    // Jika sudah login, redirect ke index
    if (isset($_SESSION['loggedin']) && $_SESSION['loggedin'] === true) {
        header('Location: index.php');
        exit;
    }

    require_once 'config.php';

    $error = '';

    // Proses login
    if ($_SERVER['REQUEST_METHOD'] == 'POST') {
        $username = $_POST['username'];
        $password = $_POST['password'];

        try {
            $query = "SELECT * FROM user WHERE username = :username";
            $stmt = $conn->prepare($query);
            $stmt->bindParam(':username', $username);
            $stmt->execute();

            if ($stmt->rowCount() == 1) {
                $user = $stmt->fetch(PDO::FETCH_ASSOC);
                
                // Verifikasi password
                if (password_verify($password, $user['password'])) {
                    // Set session
                    $_SESSION['loggedin'] = true;
                    $_SESSION['user_id'] = $user['id'];
                    $_SESSION['username'] = $user['username'];
                    $_SESSION['nama'] = $user['nama'];
                    $_SESSION['role'] = $user['role'];
                    
                    // Redirect ke halaman utama
                    header('Location: index.php');
                    exit;
                } else {
                    $error = 'Password salah!';
                }
            } else {
                $error = 'Username tidak ditemukan!';
            }
        } catch(PDOException $e) {
            $error = 'Terjadi kesalahan sistem. Silakan coba lagi.';
        }
    }
    ?>

    <!DOCTYPE html>
    <html lang="id">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Login - Kasir Toko Bangunan</title>
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
        <style>
            body {
                background-color: #f8f9fa;
                height: 100vh;
                display: flex;
                align-items: center;
                background-image: linear-gradient(135deg, #f5f7fa 0%, #c3cfe2 100%);
            }
            .login-container {
                max-width: 400px;
                width: 100%;
                padding: 30px;
                background: white;
                border-radius: 10px;
                box-shadow: 0 0 20px rgba(0, 0, 0, 0.1);
            }
            .login-header {
                text-align: center;
                margin-bottom: 30px;
            }
            .login-header img {
                width: 80px;
                margin-bottom: 15px;
            }
            .login-header h2 {
                color: #333;
                font-weight: 600;
            }
            .form-control {
                height: 45px;
                border-radius: 5px;
            }
            .btn-login {
                background-color: #4e73df;
                border: none;
                height: 45px;
                font-weight: 600;
                width: 100%;
            }
            .btn-login:hover {
                background-color: #2e59d9;
            }
            .error-message {
                color: #e74a3b;
                font-size: 14px;
                margin-top: 5px;
            }
        </style>
    </head>
    <body>
        <div class="container">
            <div class="row justify-content-center">
                <div class="login-container">
                    <div class="login-header">
                        <img src="https://cdn-icons-png.flaticon.com/512/3713/3713546.png" alt="Toko Bangunan">
                        <h2>Login Kasir</h2>
                        <p class="text-muted">Toko Bangunan Maju Jaya</p>
                    </div>

                    <?php if ($error): ?>
                        <div class="alert alert-danger"><?php echo $error; ?></div>
                    <?php endif; ?>

                    <form action="login.php" method="POST">
                        <div class="mb-3">
                            <label for="username" class="form-label">Username</label>
                            <input type="text" class="form-control" id="username" name="username" required 
                                placeholder="Masukkan username" autofocus>
                        </div>
                        <div class="mb-3">
                            <label for="password" class="form-label">Password</label>
                            <input type="password" class="form-control" id="password" name="password" required 
                                placeholder="Masukkan password">
                        </div>
                        <div class="d-grid gap-2 mb-3">
                            <button type="submit" class="btn btn-primary btn-login">Login</button>
                        </div>
                        <div class="text-center">
                            <p class="text-muted">Gunakan username dan password yang diberikan</p>
                        </div>
                    </form>
                </div>
            </div>
        </div>

        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    </body>
    </html>