<?php
session_start();
require_once 'config.php';

// Cek apakah user sudah login
if (!isset($_SESSION['loggedin'])) {
    header('Location: login.php');
    exit;
}

// Inisialisasi semua variabel dengan nilai default
$produk_keluar_hari_ini = 0;
$pendapatan_hari_ini = 0;
$produk_keluar_7hari = 0;
$produk_habis = 0;
$produk_terlaris = [];
$transaksi_terakhir = [];
$labels = [];
$data = [];
$error = null;

try {
    // Jumlah produk keluar hari ini
    $query = "SELECT IFNULL(SUM(td.jumlah), 0) as total 
              FROM transaksi_detail td
              JOIN transaksi t ON td.transaksi_id = t.id
              WHERE DATE(t.tanggal) = CURDATE()";
    $stmt = $conn->query($query);
    $result = $stmt->fetch(PDO::FETCH_ASSOC);
    $produk_keluar_hari_ini = $result['total'];

    // Pendapatan hari ini
    $query = "SELECT IFNULL(SUM(total), 0) as total 
              FROM transaksi
              WHERE DATE(tanggal) = CURDATE()";
    $stmt = $conn->query($query);
    $result = $stmt->fetch(PDO::FETCH_ASSOC);
    $pendapatan_hari_ini = $result['total'];

    // Jumlah produk keluar 7 hari terakhir
    $query = "SELECT IFNULL(SUM(td.jumlah), 0) as total 
              FROM transaksi_detail td
              JOIN transaksi t ON td.transaksi_id = t.id
              WHERE t.tanggal >= DATE_SUB(CURDATE(), INTERVAL 7 DAY)";
    $stmt = $conn->query($query);
    $result = $stmt->fetch(PDO::FETCH_ASSOC);
    $produk_keluar_7hari = $result['total'];

    // Produk yang stoknya habis
    $query = "SELECT COUNT(*) as total FROM produk WHERE stok <= 0";
    $stmt = $conn->query($query);
    $result = $stmt->fetch(PDO::FETCH_ASSOC);
    $produk_habis = $result['total'];

    // Produk terlaris 7 hari terakhir
    $query = "SELECT p.nama, IFNULL(SUM(td.jumlah), 0) as jumlah
              FROM produk p
              LEFT JOIN transaksi_detail td ON p.id = td.produk_id
              LEFT JOIN transaksi t ON td.transaksi_id = t.id AND t.tanggal >= DATE_SUB(CURDATE(), INTERVAL 7 DAY)
              GROUP BY p.id
              ORDER BY jumlah DESC
              LIMIT 5";
    $stmt = $conn->query($query);
    $produk_terlaris = $stmt->fetchAll(PDO::FETCH_ASSOC);

    // Transaksi terakhir
    $query = "SELECT id, tanggal, total 
              FROM transaksi 
              ORDER BY tanggal DESC 
              LIMIT 5";
    $stmt = $conn->query($query);
    $transaksi_terakhir = $stmt->fetchAll(PDO::FETCH_ASSOC);

    // Data untuk grafik 7 hari terakhir
    $query = "SELECT DATE(t.tanggal) as tanggal, IFNULL(SUM(td.jumlah), 0) as jumlah_produk
              FROM transaksi t
              LEFT JOIN transaksi_detail td ON t.id = td.transaksi_id
              WHERE t.tanggal >= DATE_SUB(CURDATE(), INTERVAL 7 DAY)
              GROUP BY DATE(t.tanggal)
              ORDER BY DATE(t.tanggal)";
    $stmt = $conn->query($query);
    $grafik_data = $stmt->fetchAll(PDO::FETCH_ASSOC);

    // Siapkan data untuk chart
    $labels = [];
    $data = [];
    $dates = [];

    // Buat array untuk 7 hari terakhir
    for ($i = 6; $i >= 0; $i--) {
        $date = date('Y-m-d', strtotime("-$i days"));
        $dates[$date] = 0; // Default value
    }

    // Isi dengan data dari database
    foreach ($grafik_data as $row) {
        if (array_key_exists($row['tanggal'], $dates)) {
            $dates[$row['tanggal']] = (int)$row['jumlah_produk'];
        }
    }

    // Format untuk chart
    foreach ($dates as $date => $jumlah) {
        $labels[] = date('d M', strtotime($date));
        $data[] = $jumlah;
    }

} catch (PDOException $e) {
    $error = "Gagal mengambil data statistik: " . $e->getMessage();
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Kasir Toko Bangunan</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.0/font/bootstrap-icons.css">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600&display=swap" rel="stylesheet">
    <style>
        :root {
            --primary-color: #4361ee;
            --secondary-color: #3f37c9;
            --success-color: #4cc9f0;
            --danger-color: #f72585;
            --warning-color: #f8961e;
            --info-color: #4895ef;
            --dark-color: #212529;
            --light-color: #f8f9fa;
            --sidebar-width: 250px;
        }
        
        body {
            font-family: 'Poppins', sans-serif;
            background-color: #f5f7fa;
            color: #333;
        }
        
        /* Sidebar */
        .sidebar {
            min-height: 100vh;
            width: var(--sidebar-width);
            background: linear-gradient(180deg, var(--primary-color), var(--secondary-color));
            position: fixed;
            box-shadow: 0 0 20px rgba(0, 0, 0, 0.1);
            z-index: 1000;
        }
        
        .sidebar-brand {
            padding: 1.5rem 1rem;
            color: white;
            text-align: center;
            border-bottom: 1px solid rgba(255, 255, 255, 0.1);
        }
        
        .sidebar-brand h4 {
            font-weight: 600;
            margin-bottom: 0.5rem;
        }
        
        .sidebar-user {
            text-align: center;
            padding: 1rem;
            color: white;
            border-bottom: 1px solid rgba(255, 255, 255, 0.1);
        }
        
        .sidebar-user .badge {
            background-color: rgba(255, 255, 255, 0.2);
            font-weight: 400;
            text-transform: capitalize;
        }
        
        .nav-link {
            color: rgba(255, 255, 255, 0.8);
            padding: 0.75rem 1.5rem;
            margin: 0.25rem 1rem;
            border-radius: 8px;
            transition: all 0.3s;
            font-weight: 500;
        }
        
        .nav-link:hover, .nav-link.active {
            color: white;
            background-color: rgba(255, 255, 255, 0.15);
            transform: translateX(5px);
        }
        
        .nav-link i {
            width: 24px;
            text-align: center;
            margin-right: 10px;
        }
        
        .nav-link.active {
            background-color: rgba(255, 255, 255, 0.25);
            font-weight: 600;
        }
        
        /* Main Content */
        .main-content {
            margin-left: var(--sidebar-width);
            padding: 2rem;
            min-height: 100vh;
        }
        
        .header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 2rem;
            padding-bottom: 1rem;
            border-bottom: 1px solid #e0e0e0;
        }
        
        .header h2 {
            font-weight: 600;
            color: var(--dark-color);
            margin: 0;
        }
        
        .date-info {
            background-color: white;
            padding: 0.5rem 1rem;
            border-radius: 8px;
            box-shadow: 0 2px 5px rgba(0, 0, 0, 0.05);
            font-weight: 500;
        }
        
        /* Cards */
        .card {
            border: none;
            border-radius: 12px;
            box-shadow: 0 4px 20px rgba(0, 0, 0, 0.05);
            transition: transform 0.3s, box-shadow 0.3s;
            margin-bottom: 1.5rem;
            overflow: hidden;
        }
        
        .card:hover {
            transform: translateY(-5px);
            box-shadow: 0 8px 25px rgba(0, 0, 0, 0.1);
        }
        
        .card-header {
            background-color: white;
            border-bottom: 1px solid rgba(0, 0, 0, 0.05);
            font-weight: 600;
            padding: 1.25rem 1.5rem;
        }
        
        .stat-card {
            color: white;
            border-radius: 12px;
            overflow: hidden;
            position: relative;
            z-index: 1;
        }
        
        .stat-card::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: linear-gradient(135deg, rgba(255,255,255,0.1), rgba(255,255,255,0));
            z-index: -1;
        }
        
        .stat-card .card-body {
            padding: 1.5rem;
        }
        
        .stat-card .card-title {
            font-size: 1rem;
            font-weight: 500;
            opacity: 0.9;
            margin-bottom: 0.5rem;
        }
        
        .stat-card .card-value {
            font-size: 1.75rem;
            font-weight: 600;
            margin-bottom: 0.5rem;
        }
        
        .stat-card .card-icon {
            font-size: 2.5rem;
            opacity: 0.2;
            position: absolute;
            right: 1.5rem;
            top: 1.5rem;
        }
        
        /* Chart */
        .chart-container {
            position: relative;
            height: 300px;
        }
        
        /* Tables */
        .table {
            border-collapse: separate;
            border-spacing: 0;
        }
        
        .table thead th {
            background-color: #f8f9fa;
            border-top: 1px solid #e0e0e0;
            border-bottom: 1px solid #e0e0e0;
            font-weight: 600;
            padding: 1rem;
        }
        
        .table tbody td {
            padding: 1rem;
            vertical-align: middle;
            border-bottom: 1px solid #e0e0e0;
        }
        
        .table tbody tr:last-child td {
            border-bottom: none;
        }
        
        .badge {
            padding: 0.35em 0.65em;
            font-weight: 500;
            border-radius: 8px;
        }
        
        /* Responsive */
        @media (max-width: 992px) {
            .sidebar {
                width: 80px;
                overflow: hidden;
            }
            
            .sidebar-brand, .sidebar-user, .nav-link span {
                display: none;
            }
            
            .nav-link {
                text-align: center;
                margin: 0.25rem 0.5rem;
                padding: 0.75rem 0;
            }
            
            .nav-link i {
                margin-right: 0;
                font-size: 1.25rem;
            }
            
            .main-content {
                margin-left: 80px;
            }
        }
    </style>
</head>
<body>
    <div class="d-flex">
        <!-- Sidebar -->
        <div class="sidebar">
            <div class="sidebar-brand">
                <h4>Toko Bangunan</h4>
                <div class="text-muted">Point of Sale</div>
            </div>
            
            <div class="sidebar-user">
                <div class="mb-2">
                    <i class="bi bi-person-circle fs-3"></i>
                </div>
                <h6><?php echo htmlspecialchars($_SESSION['nama'] ?? 'User'); ?></h6>
                <span class="badge"><?php echo htmlspecialchars($_SESSION['role'] ?? 'role'); ?></span>
            </div>
            
            <ul class="nav flex-column mt-3">
                <li class="nav-item">
                    <a class="nav-link active" href="index.php">
                        <i class="bi bi-speedometer2"></i>
                        <span>Dashboard</span>
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="transaksi.php">
                        <i class="bi bi-cart"></i>
                        <span>Transaksi</span>
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="produk.php">
                        <i class="bi bi-box-seam"></i>
                        <span>Produk</span>
                    </a>
                </li>
                <?php if (($_SESSION['role'] ?? '') === 'admin'): ?>
                <li class="nav-item">
                    <a class="nav-link" href="laporan.php">
                        <i class="bi bi-file-earmark-text"></i>
                        <span>Laporan</span>
                    </a>
                </li>
                <?php endif; ?>
                <li class="nav-item mt-4">
                    <a class="nav-link" href="logout.php">
                        <i class="bi bi-box-arrow-right"></i>
                        <span>Logout</span>
                    </a>
                </li>
            </ul>
        </div>

        <!-- Main Content -->
        <div class="main-content">
            <div class="header">
                <h2>Dashboard</h2>
                <div class="date-info">
                    <i class="bi bi-calendar me-2"></i>
                    <?php echo date('l, d F Y'); ?>
                </div>
            </div>

            <?php if ($error): ?>
            <div class="alert alert-danger"><?php echo htmlspecialchars($error); ?></div>
            <?php endif; ?>

            <!-- Stat Cards -->
            <div class="row">
                <div class="col-md-3">
                    <div class="stat-card" style="background-color: var(--primary-color);">
                        <div class="card-body">
                            <h5 class="card-title">Produk Keluar Hari Ini</h5>
                            <div class="card-value"><?php echo $produk_keluar_hari_ini; ?></div>
                            <small>Produk terjual</small>
                            <i class="bi bi-box-seam card-icon"></i>
                        </div>
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="stat-card" style="background-color: var(--success-color);">
                        <div class="card-body">
                            <h5 class="card-title">Pendapatan Hari Ini</h5>
                            <div class="card-value">Rp <?php echo number_format($pendapatan_hari_ini, 0, ',', '.'); ?></div>
                            <small>Total pendapatan</small>
                            <i class="bi bi-cash-stack card-icon"></i>
                        </div>
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="stat-card" style="background-color: var(--info-color);">
                        <div class="card-body">
                            <h5 class="card-title">Produk Keluar 7 Hari</h5>
                            <div class="card-value"><?php echo $produk_keluar_7hari; ?></div>
                            <small>Total produk</small>
                            <i class="bi bi-calendar-week card-icon"></i>
                        </div>
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="stat-card" style="background-color: var(--warning-color);">
                        <div class="card-body">
                            <h5 class="card-title">Produk Habis</h5>
                            <div class="card-value"><?php echo $produk_habis; ?></div>
                            <small>Perlu restock</small>
                            <i class="bi bi-exclamation-triangle card-icon"></i>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Charts and Tables -->
            <div class="row mt-4">
                <div class="col-lg-8">
                    <div class="card">
                        <div class="card-header d-flex justify-content-between align-items-center">
                            <h5 class="mb-0">Jumlah Produk Keluar 7 Hari Terakhir</h5>
                            <div class="dropdown">
                                <button class="btn btn-sm btn-outline-secondary dropdown-toggle" type="button" id="chartDropdown" data-bs-toggle="dropdown">
                                    <i class="bi bi-three-dots-vertical"></i>
                                </button>
                                <ul class="dropdown-menu dropdown-menu-end">
                                    <li><a class="dropdown-item" href="#">Minggu Ini</a></li>
                                    <li><a class="dropdown-item" href="#">Bulan Ini</a></li>
                                </ul>
                            </div>
                        </div>
                        <div class="card-body">
                            <div class="chart-container">
                                <canvas id="salesChart"></canvas>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-lg-4">
                    <div class="card">
                        <div class="card-header">
                            <h5 class="mb-0">Produk Terlaris 7 Hari</h5>
                        </div>
                        <div class="card-body">
                            <div class="list-group list-group-flush">
                                <?php if (!empty($produk_terlaris)): ?>
                                    <?php foreach ($produk_terlaris as $index => $produk): ?>
                                    <div class="list-group-item d-flex justify-content-between align-items-center px-0 py-3 border-0">
                                        <div class="d-flex align-items-center">
                                            <span class="badge bg-primary me-3"><?php echo $index + 1; ?></span>
                                            <div>
                                                <h6 class="mb-0"><?php echo htmlspecialchars($produk['nama']); ?></h6>
                                                <small class="text-muted"><?php echo $produk['jumlah']; ?> terjual</small>
                                            </div>
                                        </div>
                                        <?php if ($produk_keluar_7hari > 0): ?>
                                        <span class="badge bg-light text-dark">+<?php echo round(($produk['jumlah']/$produk_keluar_7hari)*100); ?>%</span>
                                        <?php endif; ?>
                                    </div>
                                    <?php endforeach; ?>
                                <?php else: ?>
                                    <div class="text-center py-4 text-muted">
                                        <i class="bi bi-exclamation-circle fs-4"></i>
                                        <p class="mt-2 mb-0">Tidak ada data transaksi</p>
                                    </div>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Recent Transactions -->
            <div class="row mt-4">
                <div class="col-12">
                    <div class="card">
                        <div class="card-header d-flex justify-content-between align-items-center">
                            <h5 class="mb-0">Transaksi Terakhir</h5>
                            <a href="transaksi.php" class="btn btn-sm btn-outline-primary">
                                Lihat Semua <i class="bi bi-arrow-right ms-1"></i>
                            </a>
                        </div>
                        <div class="card-body">
                            <div class="table-responsive">
                                <table class="table table-hover">
                                    <thead>
                                        <tr>
                                            <th>No. Transaksi</th>
                                            <th>Tanggal</th>
                                            <th>Total</th>
                                            <th>Jumlah Produk</th>
                                            <th>Aksi</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php if (!empty($transaksi_terakhir)): ?>
                                            <?php foreach ($transaksi_terakhir as $transaksi): ?>
                                            <tr>
                                                <td>
                                                    <span class="badge bg-light text-dark">TRX-<?php echo str_pad($transaksi['id'], 5, '0', STR_PAD_LEFT); ?></span>
                                                </td>
                                                <td><?php echo date('d/m/Y H:i', strtotime($transaksi['tanggal'])); ?></td>
                                                <td class="fw-bold">Rp <?php echo number_format($transaksi['total'], 0, ',', '.'); ?></td>
                                                <td>
                                                    <?php
                                                    try {
                                                        $query = "SELECT IFNULL(SUM(jumlah), 0) as total FROM transaksi_detail WHERE transaksi_id = ?";
                                                        $stmt = $conn->prepare($query);
                                                        $stmt->execute([$transaksi['id']]);
                                                        $jumlah_produk = $stmt->fetch(PDO::FETCH_ASSOC)['total'];
                                                        echo $jumlah_produk;
                                                    } catch (PDOException $e) {
                                                        echo "0";
                                                    }
                                                    ?>
                                                </td>
                                                <td>
                                                    <a href="detail_transaksi.php?id=<?php echo $transaksi['id']; ?>" class="btn btn-sm btn-outline-primary">
                                                        <i class="bi bi-eye"></i> Detail
                                                    </a>
                                                </td>
                                            </tr>
                                            <?php endforeach; ?>
                                        <?php else: ?>
                                            <tr>
                                                <td colspan="5" class="text-center py-4 text-muted">
                                                    <i class="bi bi-exclamation-circle fs-4"></i>
                                                    <p class="mt-2 mb-0">Tidak ada data transaksi</p>
                                                </td>
                                            </tr>
                                        <?php endif; ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <script>
        // Grafik Produk Keluar
        const ctx = document.getElementById('salesChart').getContext('2d');
        const salesChart = new Chart(ctx, {
            type: 'line',
            data: {
                labels: <?php echo json_encode($labels); ?>,
                datasets: [{
                    label: 'Jumlah Produk Keluar',
                    data: <?php echo json_encode($data); ?>,
                    backgroundColor: 'rgba(67, 97, 238, 0.1)',
                    borderColor: 'rgba(67, 97, 238, 1)',
                    borderWidth: 2,
                    tension: 0.3,
                    fill: true,
                    pointBackgroundColor: 'rgba(67, 97, 238, 1)',
                    pointBorderColor: '#fff',
                    pointHoverRadius: 6,
                    pointHoverBorderWidth: 2
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: {
                        display: false
                    },
                    tooltip: {
                        backgroundColor: 'rgba(0, 0, 0, 0.8)',
                        titleFont: {
                            size: 14,
                            weight: 'bold'
                        },
                        bodyFont: {
                            size: 12
                        },
                        callbacks: {
                            label: function(context) {
                                return context.raw.toLocaleString() + ' produk';
                            }
                        }
                    }
                },
                scales: {
                    y: {
                        beginAtZero: true,
                        grid: {
                            color: 'rgba(0, 0, 0, 0.05)'
                        },
                        ticks: {
                            precision: 0
                        }
                    },
                    x: {
                        grid: {
                            display: false
                        }
                    }
                }
            }
        });
    </script>
</body>
</html>