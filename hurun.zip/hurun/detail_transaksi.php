<?php
session_start();
require_once 'config.php';

// Check if user is logged in
if (!isset($_SESSION['loggedin'])) {
    header('Location: login.php');
    exit;
}

// Check if transaction ID is provided
if (!isset($_GET['id']) || empty($_GET['id'])) {
    header('Location: laporan.php');
    exit;
}

$transaksi_id = $_GET['id'];
$transaksi = [];
$detail_transaksi = [];
$error = '';

try {
    // Get transaction data
    $query = "SELECT * FROM transaksi WHERE id = ?";
    $stmt = $conn->prepare($query);
    $stmt->execute([$transaksi_id]);
    $transaksi = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$transaksi) {
        header('Location: laporan.php');
        exit;
    }

    // Get transaction details
    $query = "SELECT 
                td.*,
                p.nama as produk_nama,
                p.kode as produk_kode
              FROM transaksi_detail td
              JOIN produk p ON td.produk_id = p.id
              WHERE td.transaksi_id = ?";
    $stmt = $conn->prepare($query);
    $stmt->execute([$transaksi_id]);
    $detail_transaksi = $stmt->fetchAll(PDO::FETCH_ASSOC);

} catch(PDOException $e) {
    $error = "Gagal mengambil data transaksi: " . $e->getMessage();
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Detail Transaksi - Kasir Toko Bangunan</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.0/font/bootstrap-icons.css">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600&display=swap" rel="stylesheet">
    <style>
        :root {
            --primary-color: #4361ee;
            --secondary-color: #3f37c9;
            --success-color: #4cc9f0;
            --danger-color: #f72585;
            --warning-color: #f8961e;
            --info-color: #4895ef;
            --dark-color: #212529;
            --light-color: #f8f9fa;
            --sidebar-width: 250px;
        }
        
        body {
            font-family: 'Poppins', sans-serif;
            background-color: #f5f7fa;
            color: #333;
        }
        
        .sidebar {
            min-height: 100vh;
            width: var(--sidebar-width);
            background: linear-gradient(180deg, var(--primary-color), var(--secondary-color));
            position: fixed;
            box-shadow: 0 0 20px rgba(0, 0, 0, 0.1);
            z-index: 1000;
        }
        
        .sidebar-brand {
            padding: 1.5rem 1rem;
            color: white;
            text-align: center;
            border-bottom: 1px solid rgba(255, 255, 255, 0.1);
        }
        
        .sidebar-user {
            text-align: center;
            padding: 1rem;
            color: white;
            border-bottom: 1px solid rgba(255, 255, 255, 0.1);
        }
        
        .nav-link {
            color: rgba(255, 255, 255, 0.8);
            padding: 0.75rem 1.5rem;
            margin: 0.25rem 1rem;
            border-radius: 8px;
            transition: all 0.3s;
            font-weight: 500;
        }
        
        .nav-link:hover, .nav-link.active {
            color: white;
            background-color: rgba(255, 255, 255, 0.15);
            transform: translateX(5px);
        }
        
        .nav-link.active {
            background-color: rgba(255, 255, 255, 0.25);
            font-weight: 600;
        }
        
        .main-content {
            margin-left: var(--sidebar-width);
            padding: 2rem;
            min-height: 100vh;
        }
        
        .header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 2rem;
            padding-bottom: 1rem;
            border-bottom: 1px solid #e0e0e0;
        }
        
        .receipt {
            background-color: white;
            border-radius: 12px;
            box-shadow: 0 4px 20px rgba(0, 0, 0, 0.05);
            padding: 2rem;
            max-width: 600px;
            margin: 0 auto;
        }
        
        .receipt-header {
            text-align: center;
            border-bottom: 2px dashed #e0e0e0;
            padding-bottom: 1rem;
            margin-bottom: 1.5rem;
        }
        
        .receipt-footer {
            text-align: center;
            border-top: 2px dashed #e0e0e0;
            padding-top: 1rem;
            margin-top: 1.5rem;
        }
        
        .table-receipt {
            width: 100%;
        }
        
        .table-receipt thead th {
            border-bottom: 2px solid #e0e0e0;
            padding: 0.75rem;
        }
        
        .table-receipt tbody td {
            padding: 0.75rem;
            border-bottom: 1px solid #f0f0f0;
        }
        
        .table-receipt tfoot th {
            padding: 0.75rem;
            border-top: 2px solid #e0e0e0;
        }
        
        @media print {
            body * {
                visibility: hidden;
            }
            .receipt, .receipt * {
                visibility: visible;
            }
            .receipt {
                position: absolute;
                left: 0;
                top: 0;
                width: 100%;
                max-width: 100%;
                box-shadow: none;
                border: none;
            }
            .no-print {
                display: none !important;
            }
        }
        
        @media (max-width: 992px) {
            .sidebar {
                width: 80px;
                overflow: hidden;
            }
            
            .sidebar-brand, .sidebar-user, .nav-link span {
                display: none;
            }
            
            .nav-link {
                text-align: center;
                margin: 0.25rem 0.5rem;
                padding: 0.75rem 0;
            }
            
            .nav-link i {
                margin-right: 0;
                font-size: 1.25rem;
            }
            
            .main-content {
                margin-left: 80px;
            }
        }
        
        .sidebar-user .badge {
            background-color: rgba(255, 255, 255, 0.2);
            font-weight: 400;
            text-transform: capitalize;
        }
        
        .nav-link i {
            width: 24px;
            text-align: center;
            margin-right: 10px;
        }
    </style>
</head>
<body>
    <div class="d-flex">
        <!-- Sidebar -->
        <div class="sidebar no-print">
            <div class="sidebar-brand">
                <h4>Toko Bangunan</h4>
                <div class="text-muted">Point of Sale</div>
            </div>
            
            <div class="sidebar-user">
                <div class="mb-2">
                    <i class="bi bi-person-circle fs-3"></i>
                </div>
                <h6><?php echo htmlspecialchars($_SESSION['nama'] ?? 'User'); ?></h6>
                <span class="badge"><?php echo htmlspecialchars($_SESSION['role'] ?? 'role'); ?></span>
            </div>
            
            <ul class="nav flex-column mt-3">
                <li class="nav-item">
                    <a class="nav-link" href="index.php">
                        <i class="bi bi-speedometer2"></i>
                        <span>Dashboard</span>
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="transaksi.php">
                        <i class="bi bi-cart"></i>
                        <span>Transaksi</span>
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="produk.php">
                        <i class="bi bi-box-seam"></i>
                        <span>Produk</span>
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link active" href="laporan.php">
                        <i class="bi bi-file-earmark-text"></i>
                        <span>Laporan</span>
                    </a>
                </li>
                <li class="nav-item mt-4">
                    <a class="nav-link" href="logout.php">
                        <i class="bi bi-box-arrow-right"></i>
                        <span>Logout</span>
                    </a>
                </li>
            </ul>
        </div>

        <!-- Main Content -->
        <div class="main-content no-print">
            <div class="header">
                <h2>Detail Transaksi</h2>
                <div class="date-info">
                    <i class="bi bi-calendar me-2"></i>
                    <?php echo date('l, d F Y'); ?>
                </div>
            </div>

            <?php if ($error): ?>
            <div class="alert alert-danger alert-dismissible fade show">
                <i class="bi bi-exclamation-circle me-2"></i>
                <?php echo htmlspecialchars($error); ?>
                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>
            <?php endif; ?>

            <div class="card border-0 shadow-sm mb-4">
                <div class="card-header bg-white d-flex justify-content-between align-items-center">
                    <h5 class="mb-0">
                        <i class="bi bi-receipt me-2"></i>
                        Transaksi #TRX-<?php echo str_pad($transaksi['id'], 5, '0', STR_PAD_LEFT); ?>
                    </h5>
                    <div>
                        <a href="laporan.php" class="btn btn-outline-secondary me-2">
                            <i class="bi bi-arrow-left me-1"></i> Kembali
                        </a>
                        <button onclick="window.print()" class="btn btn-primary">
                            <i class="bi bi-printer me-1"></i> Cetak
                        </button>
                    </div>
                </div>
                <div class="card-body">
                    <!-- Receipt Structure -->
                    <div class="receipt">
                        <div class="receipt-header">
                            <h3 class="mb-2">Toko Bangunan</h3>
                            <p class="mb-1 text-muted">Jl. Contoh No. 123, Kota</p>
                            <p class="mb-1 text-muted">Telp: 08123456789</p>
                        </div>

                        <div class="mb-4">
                            <div class="d-flex justify-content-between mb-2">
                                <span class="text-muted">No. Transaksi:</span>
                                <strong>TRX-<?php echo str_pad($transaksi['id'], 5, '0', STR_PAD_LEFT); ?></strong>
                            </div>
                            <div class="d-flex justify-content-between mb-2">
                                <span class="text-muted">Tanggal:</span>
                                <strong><?php echo date('d/m/Y H:i', strtotime($transaksi['tanggal'])); ?></strong>
                            </div>
                            <div class="d-flex justify-content-between">
                                <span class="text-muted">Kasir:</span>
                                <strong><?php echo htmlspecialchars($_SESSION['nama']); ?></strong>
                            </div>
                        </div>

                        <table class="table-receipt">
                            <thead>
                                <tr>
                                    <th>Produk</th>
                                    <th class="text-end">Harga</th>
                                    <th class="text-end">Qty</th>
                                    <th class="text-end">Subtotal</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($detail_transaksi as $item): ?>
                                <tr>
                                    <td>
                                        <?php echo htmlspecialchars($item['produk_nama']); ?>
                                        <small class="text-muted d-block"><?php echo $item['produk_kode']; ?></small>
                                    </td>
                                    <td class="text-end">Rp <?php echo number_format($item['harga'], 0, ',', '.'); ?></td>
                                    <td class="text-end"><?php echo $item['jumlah']; ?></td>
                                    <td class="text-end">Rp <?php echo number_format($item['subtotal'], 0, ',', '.'); ?></td>
                                </tr>
                                <?php endforeach; ?>
                            </tbody>
                            <tfoot>
                                <tr>
                                    <th colspan="3" class="text-end">Total:</th>
                                    <th class="text-end">Rp <?php echo number_format($transaksi['total'], 0, ',', '.'); ?></th>
                                </tr>
                                <tr>
                                    <th colspan="3" class="text-end">Bayar:</th>
                                    <th class="text-end">Rp <?php echo number_format($transaksi['bayar'], 0, ',', '.'); ?></th>
                                </tr>
                                <tr>
                                    <th colspan="3" class="text-end">Kembali:</th>
                                    <th class="text-end">Rp <?php echo number_format($transaksi['kembali'], 0, ',', '.'); ?></th>
                                </tr>
                            </tfoot>
                        </table>

                        <div class="receipt-footer">
                            <p class="mb-2">Terima kasih telah berbelanja</p>
                            <p class="text-muted small">Barang yang sudah dibeli tidak dapat ditukar/dikembalikan</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        // Improve print functionality
        document.addEventListener('DOMContentLoaded', function() {
            // Set focus to print button for better keyboard navigation
            document.querySelector('button[onclick="window.print()"]').focus();
        });
    </script>
</body>
</html>