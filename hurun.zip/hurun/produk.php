<?php
session_start();
require_once 'config.php';

// Check if user is logged in
if (!isset($_SESSION['loggedin'])) {
    header('Location: login.php');
    exit;
}

// Initialize variables
$error = '';
$success = '';
$products = [];
$edit_product = null;

// Handle delete product
if (isset($_GET['delete'])) {
    $id = $_GET['delete'];
    
    try {
        // Check if product exists in any transaction
        $stmt = $conn->prepare("SELECT COUNT(*) FROM transaksi_detail WHERE produk_id = ?");
        $stmt->execute([$id]);
        $count = $stmt->fetchColumn();
        
        if ($count > 0) {
            $_SESSION['error'] = "Produk tidak dapat dihapus karena sudah tercatat dalam transaksi";
        } else {
            $stmt = $conn->prepare("DELETE FROM produk WHERE id = ?");
            $stmt->execute([$id]);
            $_SESSION['success'] = "Produk berhasil dihapus";
        }
    } catch (PDOException $e) {
        $_SESSION['error'] = "Gagal menghapus produk: " . $e->getMessage();
    }
    header('Location: produk.php');
    exit;
}

// Handle form submission (add/edit product)
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $id = $_POST['id'] ?? null;
    $kode = trim($_POST['kode']);
    $nama = trim($_POST['nama']);
    $harga = (int)$_POST['harga'];
    $stok = (int)$_POST['stok'];
    
    // Validate input
    if (empty($kode) || empty($nama) || $harga <= 0 || $stok < 0) {
        $_SESSION['error'] = "Semua field harus diisi dengan nilai yang valid";
        header('Location: produk.php');
        exit;
    }
    
    try {
        if (isset($_POST['add_product'])) {
            // Add new product
            $stmt = $conn->prepare("INSERT INTO produk (kode, nama, harga, stok) VALUES (?, ?, ?, ?)");
            $stmt->execute([$kode, $nama, $harga, $stok]);
            $_SESSION['success'] = "Produk berhasil ditambahkan";
        } else {
            // Update existing product
            $stmt = $conn->prepare("UPDATE produk SET kode = ?, nama = ?, harga = ?, stok = ? WHERE id = ?");
            $stmt->execute([$kode, $nama, $harga, $stok, $id]);
            $_SESSION['success'] = "Produk berhasil diperbarui";
        }
    } catch (PDOException $e) {
        $_SESSION['error'] = (strpos($e->getMessage(), 'Duplicate entry') !== false) 
            ? "Kode produk sudah digunakan" 
            : "Gagal menyimpan produk: " . $e->getMessage();
    }
    header('Location: produk.php');
    exit;
}

// Get product data for editing
if (isset($_GET['edit'])) {
    $id = $_GET['edit'];
    $stmt = $conn->prepare("SELECT * FROM produk WHERE id = ?");
    $stmt->execute([$id]);
    $edit_product = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if (!$edit_product) {
        $_SESSION['error'] = "Produk tidak ditemukan";
        header('Location: produk.php');
        exit;
    }
}

// Get all products with search functionality
$search = $_GET['search'] ?? '';
$query = "SELECT * FROM produk";
$params = [];

if (!empty($search)) {
    $query .= " WHERE nama LIKE ? OR kode LIKE ?";
    $params = ["%$search%", "%$search%"];
}

$query .= " ORDER BY nama ASC";
$stmt = $conn->prepare($query);
$stmt->execute($params);
$products = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Produk - Kasir Toko Bangunan</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.0/font/bootstrap-icons.css">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600&display=swap" rel="stylesheet">
    <style>
        :root {
            --primary-color: #4361ee;
            --secondary-color: #3f37c9;
            --success-color: #4cc9f0;
            --danger-color: #f72585;
            --warning-color: #f8961e;
            --info-color: #4895ef;
            --dark-color: #212529;
            --light-color: #f8f9fa;
            --sidebar-width: 250px;
        }
        
        body {
            font-family: 'Poppins', sans-serif;
            background-color: #f5f7fa;
            color: #333;
        }
        
        .sidebar {
            min-height: 100vh;
            width: var(--sidebar-width);
            background: linear-gradient(180deg, var(--primary-color), var(--secondary-color));
            position: fixed;
            box-shadow: 0 0 20px rgba(0, 0, 0, 0.1);
            z-index: 1000;
        }
        
        .sidebar-brand {
            padding: 1.5rem 1rem;
            color: white;
            text-align: center;
            border-bottom: 1px solid rgba(255, 255, 255, 0.1);
        }
        
        .sidebar-user {
            text-align: center;
            padding: 1rem;
            color: white;
            border-bottom: 1px solid rgba(255, 255, 255, 0.1);
        }
        
        .nav-link {
            color: rgba(255, 255, 255, 0.8);
            padding: 0.75rem 1.5rem;
            margin: 0.25rem 1rem;
            border-radius: 8px;
            transition: all 0.3s;
            font-weight: 500;
        }
        
        .nav-link:hover, .nav-link.active {
            color: white;
            background-color: rgba(255, 255, 255, 0.15);
            transform: translateX(5px);
        }
        
        .nav-link.active {
            background-color: rgba(255, 255, 255, 0.25);
            font-weight: 600;
        }
        
        .main-content {
            margin-left: var(--sidebar-width);
            padding: 2rem;
            min-height: 100vh;
        }
        
        .header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 2rem;
            padding-bottom: 1rem;
            border-bottom: 1px solid #e0e0e0;
        }
        
        .product-card {
            transition: all 0.3s;
            border-radius: 10px;
            overflow: hidden;
            border: 1px solid rgba(0, 0, 0, 0.1);
        }
        
        .stok-habis {
            color: var(--danger-color);
            font-weight: bold;
        }
        
        .stok-sedikit {
            color: var(--warning-color);
            font-weight: bold;
        }
        
        .stok-cukup {
            color: var(--success-color);
            font-weight: bold;
        }
        
        .search-box {
            max-width: 300px;
        }
        
        .table-responsive {
            overflow-x: auto;
        }
        
        @media (max-width: 992px) {
            .sidebar {
                width: 80px;
                overflow: hidden;
            }
            
            .sidebar-brand, .sidebar-user, .nav-link span {
                display: none;
            }
            
            .nav-link {
                text-align: center;
                margin: 0.25rem 0.5rem;
                padding: 0.75rem 0;
            }
            
            .nav-link i {
                margin-right: 0;
                font-size: 1.25rem;
            }
            
            .main-content {
                margin-left: 80px;
            }
        }
         
        /* Sidebar */
        .sidebar {
            min-height: 100vh;
            width: var(--sidebar-width);
            background: linear-gradient(180deg, var(--primary-color), var(--secondary-color));
            position: fixed;
            box-shadow: 0 0 20px rgba(0, 0, 0, 0.1);
            z-index: 1000;
        }
        
        .sidebar-brand {
            padding: 1.5rem 1rem;
            color: white;
            text-align: center;
            border-bottom: 1px solid rgba(255, 255, 255, 0.1);
        }
        
        .sidebar-brand h4 {
            font-weight: 600;
            margin-bottom: 0.5rem;
        }
        
        .sidebar-user {
            text-align: center;
            padding: 1rem;
            color: white;
            border-bottom: 1px solid rgba(255, 255, 255, 0.1);
        }
        
        .sidebar-user .badge {
            background-color: rgba(255, 255, 255, 0.2);
            font-weight: 400;
            text-transform: capitalize;
        }
        
        .nav-link i {
            width: 24px;
            text-align: center;
            margin-right: 10px;
        }
        
    </style>
</head>
<body>
    <div class="d-flex">
        <!-- Sidebar -->
        <div class="sidebar">
            <div class="sidebar-brand">
                <h4>Toko Bangunan</h4>
                <div class="text-muted">Point of Sale</div>
            </div>
            
            <div class="sidebar-user">
                <div class="mb-2">
                    <i class="bi bi-person-circle fs-3"></i>
                </div>
                <h6><?php echo htmlspecialchars($_SESSION['nama'] ?? 'User'); ?></h6>
                <span class="badge"><?php echo htmlspecialchars($_SESSION['role'] ?? 'role'); ?></span>
            </div>
            
            <ul class="nav flex-column mt-3">
                <li class="nav-item">
                    <a class="nav-link" href="index.php">
                        <i class="bi bi-speedometer2"></i>
                        <span>Dashboard</span>
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="transaksi.php">
                        <i class="bi bi-cart"></i>
                        <span>Transaksi</span>
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link active" href="produk.php">
                        <i class="bi bi-box-seam"></i>
                        <span>Produk</span>
                    </a>
                </li>
                <?php if (($_SESSION['role'] ?? '') === 'admin'): ?>
                <li class="nav-item">
                    <a class="nav-link" href="laporan.php">
                        <i class="bi bi-file-earmark-text"></i>
                        <span>Laporan</span>
                    </a>
                </li>
                <?php endif; ?>
                <li class="nav-item mt-4">
                    <a class="nav-link" href="logout.php">
                        <i class="bi bi-box-arrow-right"></i>
                        <span>Logout</span>
                    </a>
                </li>
            </ul>
        </div>

        <!-- Main Content -->
        <div class="main-content">
            <div class="header">
                <h2>Manajemen Produk</h2>
                <div class="d-flex align-items-center">
                    <form method="GET" action="produk.php" class="me-3 search-box">
                        <div class="input-group">
                            <input type="text" class="form-control" name="search" placeholder="Cari produk..." 
                                value="<?php echo htmlspecialchars($search); ?>">
                            <button class="btn btn-outline-secondary" type="submit">
                                <i class="bi bi-search"></i>
                            </button>
                            <?php if (!empty($search)): ?>
                                <a href="produk.php" class="btn btn-outline-danger">
                                    <i class="bi bi-x"></i>
                                </a>
                            <?php endif; ?>
                        </div>
                    </form>
                    <button class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#productModal">
                        <i class="bi bi-plus-circle me-1"></i> Tambah Produk
                    </button>
                </div>
            </div>

            <!-- Alert messages -->
            <?php if (isset($_SESSION['error'])): ?>
                <div class="alert alert-danger alert-dismissible fade show">
                    <i class="bi bi-exclamation-circle me-2"></i>
                    <?php echo htmlspecialchars($_SESSION['error']); ?>
                    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                </div>
                <?php unset($_SESSION['error']); ?>
            <?php endif; ?>

            <?php if (isset($_SESSION['success'])): ?>
                <div class="alert alert-success alert-dismissible fade show">
                    <i class="bi bi-check-circle me-2"></i>
                    <?php echo htmlspecialchars($_SESSION['success']); ?>
                    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                </div>
                <?php unset($_SESSION['success']); ?>
            <?php endif; ?>

            <!-- Products Table -->
            <div class="card border-0 shadow-sm">
                <div class="card-body p-0">
                    <div class="table-responsive">
                        <table class="table table-hover mb-0">
                            <thead class="table-light">
                                <tr>
                                    <th width="120">Kode</th>
                                    <th>Nama Produk</th>
                                    <th width="150">Harga</th>
                                    <th width="100">Stok</th>
                                    <th width="120">Status</th>
                                    <th width="120" class="text-end">Aksi</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php if (empty($products)): ?>
                                    <tr>
                                        <td colspan="6" class="text-center py-4">
                                            <i class="bi bi-box-open fs-1 text-muted"></i>
                                            <p class="mt-2 mb-0">Tidak ada data produk</p>
                                            <?php if (!empty($search)): ?>
                                                <a href="produk.php" class="btn btn-sm btn-primary mt-2">
                                                    Tampilkan Semua Produk
                                                </a>
                                            <?php endif; ?>
                                        </td>
                                    </tr>
                                <?php else: ?>
                                    <?php foreach ($products as $product): ?>
                                        <?php
                                        // Determine stock status
                                        if ($product['stok'] == 0) {
                                            $status_class = 'stok-habis';
                                            $status_text = 'Habis';
                                        } elseif ($product['stok'] < 10) {
                                            $status_class = 'stok-sedikit';
                                            $status_text = 'Hampir Habis';
                                        } else {
                                            $status_class = 'stok-cukup';
                                            $status_text = 'Tersedia';
                                        }
                                        ?>
                                        <tr>
                                            <td>
                                                <span class="badge bg-light text-dark"><?php echo htmlspecialchars($product['kode']); ?></span>
                                            </td>
                                            <td><?php echo htmlspecialchars($product['nama']); ?></td>
                                            <td>Rp <?php echo number_format($product['harga'], 0, ',', '.'); ?></td>
                                            <td class="<?php echo $status_class; ?>">
                                                <?php echo $product['stok']; ?>
                                            </td>
                                            <td>
                                                <span class="badge <?php echo str_replace('stok-', 'bg-', $status_class); ?>">
                                                    <?php echo $status_text; ?>
                                                </span>
                                            </td>
                                            <td class="text-end">
                                                <a href="produk.php?edit=<?php echo $product['id']; ?>" 
                                                   class="btn btn-sm btn-outline-primary me-1"
                                                   title="Edit">
                                                    <i class="bi bi-pencil"></i>
                                                </a>
                                                <a href="produk.php?delete=<?php echo $product['id']; ?>" 
                                                   class="btn btn-sm btn-outline-danger"
                                                   title="Hapus"
                                                   onclick="return confirm('Apakah Anda yakin ingin menghapus produk ini?')">
                                                    <i class="bi bi-trash"></i>
                                                </a>
                                            </td>
                                        </tr>
                                    <?php endforeach; ?>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Product Modal (Add/Edit) -->
    <div class="modal fade" id="productModal" tabindex="-1" aria-labelledby="productModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <form method="POST" action="produk.php">
                    <div class="modal-header">
                        <h5 class="modal-title" id="productModalLabel">
                            <?php echo isset($edit_product) ? 'Edit Produk' : 'Tambah Produk Baru'; ?>
                        </h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <div class="modal-body">
                        <input type="hidden" name="id" value="<?php echo $edit_product['id'] ?? ''; ?>">
                        <?php if (isset($edit_product)): ?>
                            <input type="hidden" name="edit_product" value="1">
                        <?php else: ?>
                            <input type="hidden" name="add_product" value="1">
                        <?php endif; ?>
                        
                        <div class="mb-3">
                            <label for="kode" class="form-label">Kode Produk</label>
                            <input type="text" class="form-control" id="kode" name="kode" 
                                value="<?php echo htmlspecialchars($edit_product['kode'] ?? ''); ?>" required>
                        </div>
                        <div class="mb-3">
                            <label for="nama" class="form-label">Nama Produk</label>
                            <input type="text" class="form-control" id="nama" name="nama" 
                                value="<?php echo htmlspecialchars($edit_product['nama'] ?? ''); ?>" required>
                        </div>
                        <div class="mb-3">
                            <label for="harga" class="form-label">Harga</label>
                            <div class="input-group">
                                <span class="input-group-text">Rp</span>
                                <input type="number" class="form-control" id="harga" name="harga" 
                                    value="<?php echo $edit_product['harga'] ?? ''; ?>" min="1" required>
                            </div>
                        </div>
                        <div class="mb-3">
                            <label for="stok" class="form-label">Stok</label>
                            <input type="number" class="form-control" id="stok" name="stok" 
                                value="<?php echo $edit_product['stok'] ?? '0'; ?>" min="0" required>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Tutup</button>
                        <button type="submit" class="btn btn-primary">
                            <i class="bi bi-save me-1"></i> Simpan
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        // Auto show modal if editing
        <?php if (isset($edit_product)): ?>
            document.addEventListener('DOMContentLoaded', function() {
                var modal = new bootstrap.Modal(document.getElementById('productModal'));
                modal.show();
                
                // Redirect to clean URL when modal is closed
                document.getElementById('productModal').addEventListener('hidden.bs.modal', function() {
                    window.location.href = 'produk.php';
                });
            });
        <?php endif; ?>
        
        // Focus on search input when search is active
        <?php if (!empty($search)): ?>
            document.addEventListener('DOMContentLoaded', function() {
                document.querySelector('input[name="search"]').focus();
            });
        <?php endif; ?>
    </script>
</body>
</html>