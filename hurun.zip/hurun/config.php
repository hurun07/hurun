<?php
// File config.php - Konfigurasi Database dan Setting Aplikasi

// Error Reporting
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Database Configuration
define('DB_HOST', 'localhost');
define('DB_USER', 'root');
define('DB_PASS', '');
define('DB_NAME', 'kasir_toko_bangunan');

// Koneksi ke Database
try {
    $conn = new PDO("mysql:host=".DB_HOST.";dbname=".DB_NAME, DB_USER, DB_PASS);
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    
    // Set karakter set ke UTF-8
    $conn->exec("SET NAMES 'utf8'");
    $conn->exec("SET CHARACTER SET 'utf8'");
} catch(PDOException $e) {
    die("Koneksi database gagal: " . $e->getMessage());
}

// Setting Aplikasi
define('APP_NAME', 'Kasir Toko Bangunan');
define('APP_VERSION', '1.0.0');
define('CURRENCY', 'Rp ');
date_default_timezone_set('Asia/Jakarta');

// Fungsi dasar
function format_rupiah($angka) {
    return CURRENCY . number_format($angka, 0, ',', '.');
}

// Mulai session
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}
?>