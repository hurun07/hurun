<?php
session_start();
require_once 'config.php';

// Cek apakah user sudah login
if (!isset($_SESSION['loggedin'])) {
    header('Location: login.php');
    exit;
}

// Inisialisasi variabel
$error = '';
$success = '';
$produk = [];
$cart = $_SESSION['cart'] ?? [];
$total = 0;

// Ambil data produk dari database
try {
    $stmt = $conn->query("SELECT * FROM produk WHERE stok > 0 ORDER BY nama");
    $produk = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    $error = "Gagal mengambil data produk: " . $e->getMessage();
}

// Proses tambah produk ke keranjang
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['tambah_produk'])) {
    $produk_id = $_POST['produk_id'];
    $jumlah = (int)$_POST['jumlah'];

    try {
        // Cari produk yang dipilih
        $stmt = $conn->prepare("SELECT * FROM produk WHERE id = ?");
        $stmt->execute([$produk_id]);
        $produk_dipilih = $stmt->fetch(PDO::FETCH_ASSOC);

        if ($produk_dipilih) {
            // Cek stok
            if ($produk_dipilih['stok'] < $jumlah) {
                $error = "Stok tidak mencukupi! Stok tersedia: " . $produk_dipilih['stok'];
            } else {
                // Tambahkan ke keranjang
                if (isset($cart[$produk_id])) {
                    $cart[$produk_id]['jumlah'] += $jumlah;
                } else {
                    $cart[$produk_id] = [
                        'id' => $produk_dipilih['id'],
                        'kode' => $produk_dipilih['kode'],
                        'nama' => $produk_dipilih['nama'],
                        'harga' => $produk_dipilih['harga'],
                        'jumlah' => $jumlah
                    ];
                }
                $_SESSION['cart'] = $cart;
                $success = "Produk berhasil ditambahkan ke keranjang";
            }
        }
    } catch (PDOException $e) {
        $error = "Gagal menambahkan produk: " . $e->getMessage();
    }
}

// Proses hapus item dari keranjang
if (isset($_GET['hapus'])) {
    $produk_id = $_GET['hapus'];
    if (isset($cart[$produk_id])) {
        unset($cart[$produk_id]);
        $_SESSION['cart'] = $cart;
        $success = "Produk berhasil dihapus dari keranjang";
    }
}

// Proses simpan transaksi
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['simpan_transaksi'])) {
    $bayar = (int)$_POST['bayar'];

    // Hitung total
    $total = 0;
    foreach ($cart as $item) {
        $total += $item['harga'] * $item['jumlah'];
    }

    if ($bayar < $total) {
        $error = "Pembayaran kurang!";
    } elseif (empty($cart)) {
        $error = "Keranjang belanja kosong!";
    } else {
        try {
            $conn->beginTransaction();

            // Simpan transaksi
            $stmt = $conn->prepare("INSERT INTO transaksi (total, bayar, kembali) VALUES (?, ?, ?)");
            $kembali = $bayar - $total;
            $stmt->execute([$total, $bayar, $kembali]);
            $transaksi_id = $conn->lastInsertId();

            // Simpan detail transaksi dan update stok
            foreach ($cart as $item) {
                $subtotal = $item['harga'] * $item['jumlah'];

                // Simpan detail transaksi
                $stmt = $conn->prepare("INSERT INTO transaksi_detail (transaksi_id, produk_id, harga, jumlah, subtotal) 
                                      VALUES (?, ?, ?, ?, ?)");
                $stmt->execute([$transaksi_id, $item['id'], $item['harga'], $item['jumlah'], $subtotal]);

                // Update stok produk
                $stmt = $conn->prepare("UPDATE produk SET stok = stok - ? WHERE id = ?");
                $stmt->execute([$item['jumlah'], $item['id']]);
            }

            $conn->commit();
            $success = "Transaksi berhasil disimpan! No. Transaksi: TRX-" . str_pad($transaksi_id, 5, '0', STR_PAD_LEFT);

            // Kosongkan keranjang
            unset($_SESSION['cart']);
            $cart = [];
        } catch (PDOException $e) {
            $conn->rollBack();
            $error = "Gagal menyimpan transaksi: " . $e->getMessage();
        }
    }
}

// Hitung total belanja
foreach ($cart as $item) {
    $total += $item['harga'] * $item['jumlah'];
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Transaksi - Kasir Toko Bangunan</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.0/font/bootstrap-icons.css">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600&display=swap" rel="stylesheet">
    <style>
        :root {
            --primary-color: #4361ee;
            --secondary-color: #3f37c9;
            --success-color: #4cc9f0;
            --danger-color: #f72585;
            --warning-color: #f8961e;
            --info-color: #4895ef;
            --dark-color: #212529;
            --light-color: #f8f9fa;
            --sidebar-width: 250px;
        }
        
        body {
            font-family: 'Poppins', sans-serif;
            background-color: #f5f7fa;
            color: #333;
        }
        
        
        /* Sidebar */
        .sidebar {
            min-height: 100vh;
            width: var(--sidebar-width);
            background: linear-gradient(180deg, var(--primary-color), var(--secondary-color));
            position: fixed;
            box-shadow: 0 0 20px rgba(0, 0, 0, 0.1);
            z-index: 1000;
        }
        
        .sidebar-brand {
            padding: 1.5rem 1rem;
            color: white;
            text-align: center;
            border-bottom: 1px solid rgba(255, 255, 255, 0.1);
        }
        
        .sidebar-brand h4 {
            font-weight: 600;
            margin-bottom: 0.5rem;
        }
        
        .sidebar-user {
            text-align: center;
            padding: 1rem;
            color: white;
            border-bottom: 1px solid rgba(255, 255, 255, 0.1);
        }
        
        .sidebar-user .badge {
            background-color: rgba(255, 255, 255, 0.2);
            font-weight: 400;
            text-transform: capitalize;
        }
        
        .nav-link i {
            width: 24px;
            text-align: center;
            margin-right: 10px;
        }
      
        .nav-link {
            color: rgba(255, 255, 255, 0.8);
            padding: 0.75rem 1.5rem;
            margin: 0.25rem 1rem;
            border-radius: 8px;
            transition: all 0.3s;
            font-weight: 500;
        }
        
        .nav-link:hover, .nav-link.active {
            color: white;
            background-color: rgba(255, 255, 255, 0.15);
            transform: translateX(5px);
        }
        
        .nav-link.active {
            background-color: rgba(255, 255, 255, 0.25);
            font-weight: 600;
        }
        
        .main-content {
            margin-left: var(--sidebar-width);
            padding: 2rem;
            min-height: 100vh;
        }
        
        .header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 2rem;
            padding-bottom: 1rem;
            border-bottom: 1px solid #e0e0e0;
        }
        
        .product-card {
            transition: all 0.3s;
            border-radius: 10px;
            overflow: hidden;
            border: 1px solid rgba(0, 0, 0, 0.1);
        }
        
        .product-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 10px 20px rgba(0, 0, 0, 0.1);
        }
        
        .product-card .card-body {
            padding: 1.25rem;
        }
        
        .cart-item {
            transition: all 0.3s;
            padding: 0.75rem 0;
            border-bottom: 1px solid rgba(0, 0, 0, 0.05);
        }
        
        .cart-item:hover {
            background-color: rgba(0, 0, 0, 0.02);
        }
        
        .total-card {
            background-color: #f8f9fa;
            border-radius: 10px;
            padding: 1.5rem;
        }
        
        @media (max-width: 992px) {
            .sidebar {
                width: 80px;
                overflow: hidden;
            }
            
            .sidebar-brand, .sidebar-user, .nav-link span {
                display: none;
            }
            
            .nav-link {
                text-align: center;
                margin: 0.25rem 0.5rem;
                padding: 0.75rem 0;
            }
            
            .nav-link i {
                margin-right: 0;
                font-size: 1.25rem;
            }
            
            .main-content {
                margin-left: 80px;
            }
        }
    </style>
</head>
<body>
    <div class="d-flex">
        <!-- Sidebar -->
        <div class="sidebar">
            <div class="sidebar-brand">
                <h4>Toko Bangunan</h4>
                <div class="text-muted">Point of Sale</div>
            </div>

           <div class="sidebar-user">
                <div class="mb-2">
                    <i class="bi bi-person-circle fs-3"></i>
                </div>
                <h6><?php echo htmlspecialchars($_SESSION['nama'] ?? 'User'); ?></h6>
                <span class="badge"><?php echo htmlspecialchars($_SESSION['role'] ?? 'role'); ?></span>
            </div>
            
            <ul class="nav flex-column mt-3">
                <li class="nav-item">
                    <a class="nav-link" href="index.php">
                        <i class="bi bi-speedometer2"></i>
                        <span>Dashboard</span>
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link active" href="transaksi.php">
                        <i class="bi bi-cart"></i>
                        <span>Transaksi</span>
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="produk.php">
                        <i class="bi bi-box-seam"></i>
                        <span>Produk</span>
                    </a>
                </li>
                <?php if (($_SESSION['role'] ?? '') === 'admin'): ?>
                <li class="nav-item">
                    <a class="nav-link" href="laporan.php">
                        <i class="bi bi-file-earmark-text"></i>
                        <span>Laporan</span>
                    </a>
                </li>
                <?php endif; ?>
                <li class="nav-item mt-4">
                    <a class="nav-link" href="logout.php">
                        <i class="bi bi-box-arrow-right"></i>
                        <span>Logout</span>
                    </a>
                </li>
            </ul>
        </div>

        <!-- Main Content -->
        <div class="main-content">
            <div class="header">
                <h2>Transaksi</h2>
                <div class="date-info">
                    <i class="bi bi-calendar me-2"></i>
                    <?php echo date('l, d F Y'); ?>
                </div>
            </div>

            <?php if ($error): ?>
            <div class="alert alert-danger alert-dismissible fade show">
                <?php echo htmlspecialchars($error); ?>
                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>
            <?php endif; ?>

            <?php if ($success): ?>
            <div class="alert alert-success alert-dismissible fade show">
                <?php echo htmlspecialchars($success); ?>
                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>
            <?php endif; ?>

            <div class="row">
                <!-- Daftar Produk -->
                <div class="col-lg-8">
                    <div class="card mb-4 border-0 shadow-sm">
                        <div class="card-header bg-white border-0">
                            <h5 class="mb-0 text-primary"><i class="bi bi-box-seam me-2"></i> Daftar Produk</h5>
                        </div>
                        <div class="card-body">
                            <?php if (empty($produk)): ?>
                                <div class="alert alert-warning">
                                    <i class="bi bi-exclamation-circle me-2"></i> Tidak ada produk tersedia
                                </div>
                            <?php else: ?>
                                <div class="row row-cols-1 row-cols-md-2 row-cols-lg-3 g-4">
                                    <?php foreach ($produk as $p): ?>
                                        <div class="col">
                                            <div class="card product-card h-100" data-bs-toggle="modal" data-bs-target="#produkModal"
                                                data-id="<?= $p['id'] ?>" data-nama="<?= htmlspecialchars($p['nama']) ?>"
                                                data-harga="<?= $p['harga'] ?>" data-stok="<?= $p['stok'] ?>">
                                                <div class="card-body">
                                                    <h6 class="card-title text-truncate"><?= htmlspecialchars($p['kode']) ?> - <?= htmlspecialchars($p['nama']) ?></h6>
                                                    <div class="d-flex justify-content-between align-items-center">
                                                        <span class="badge bg-primary">Rp <?= number_format($p['harga'], 0, ',', '.') ?></span>
                                                        <span class="badge bg-light text-dark">Stok: <?= $p['stok'] ?></span>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    <?php endforeach; ?>
                                </div>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>

                <!-- Keranjang Belanja -->
                <div class="col-lg-4">
                    <div class="card mb-4 border-0 shadow-sm">
                        <div class="card-header bg-white border-0">
                            <h5 class="mb-0 text-success"><i class="bi bi-cart me-2"></i> Keranjang Belanja</h5>
                        </div>
                        <div class="card-body">
                            <?php if (empty($cart)): ?>
                                <div class="alert alert-info">
                                    <i class="bi bi-info-circle me-2"></i> Keranjang belanja kosong
                                </div>
                            <?php else: ?>
                                <div class="mb-3">
                                    <?php foreach ($cart as $item): ?>
                                        <div class="cart-item">
                                            <div class="d-flex justify-content-between align-items-start">
                                                <div class="flex-grow-1">
                                                    <h6 class="mb-1"><?= htmlspecialchars($item['nama']) ?></h6>
                                                    <small class="text-muted"><?= $item['jumlah'] ?> x Rp <?= number_format($item['harga'], 0, ',', '.') ?></small>
                                                </div>
                                                <div class="text-end">
                                                    <strong>Rp <?= number_format($item['harga'] * $item['jumlah'], 0, ',', '.') ?></strong>
                                                    <a href="transaksi.php?hapus=<?= $item['id'] ?>" class="text-danger ms-2">
                                                        <i class="bi bi-trash"></i>
                                                    </a>
                                                </div>
                                            </div>
                                        </div>
                                    <?php endforeach; ?>
                                </div>
                                
                                <div class="total-card mb-4">
                                    <div class="d-flex justify-content-between mb-2">
                                        <span>Subtotal:</span>
                                        <span>Rp <?= number_format($total, 0, ',', '.') ?></span>
                                    </div>
                                    <div class="d-flex justify-content-between fw-bold fs-5">
                                        <span>Total:</span>
                                        <span>Rp <?= number_format($total, 0, ',', '.') ?></span>
                                    </div>
                                </div>
                                
                                <form method="POST" action="transaksi.php">
                                    <div class="mb-3">
                                        <label for="bayar" class="form-label">Bayar</label>
                                        <div class="input-group">
                                            <span class="input-group-text">Rp</span>
                                            <input type="number" class="form-control" id="bayar" name="bayar"
                                                value="<?= $total ?>" min="<?= $total ?>" required>
                                        </div>
                                    </div>
                                    <div class="mb-3">
                                        <label for="kembali" class="form-label">Kembali</label>
                                        <div class="input-group">
                                            <span class="input-group-text">Rp</span>
                                            <input type="text" class="form-control" id="kembali" value="0" readonly>
                                        </div>
                                    </div>
                                    <div class="d-grid gap-2">
                                        <button type="submit" name="simpan_transaksi" class="btn btn-primary btn-lg"
                                            <?= empty($cart) ? 'disabled' : '' ?>>
                                            <i class="bi bi-save me-1"></i> Simpan Transaksi
                                        </button>
                                    </div>
                                </form>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Modal Tambah Produk -->
    <div class="modal fade" id="produkModal" tabindex="-1" aria-labelledby="produkModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <form method="POST" action="transaksi.php">
                    <div class="modal-header">
                        <h5 class="modal-title" id="produkModalLabel">Tambah Produk</h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <div class="modal-body">
                        <input type="hidden" id="modal_produk_id" name="produk_id">
                        <div class="mb-3">
                            <label class="form-label">Nama Produk</label>
                            <input type="text" class="form-control" id="modal_produk_nama" readonly>
                        </div>
                        <div class="row">
                            <div class="col-md-6 mb-3">
                                <label class="form-label">Harga</label>
                                <input type="text" class="form-control" id="modal_produk_harga" readonly>
                            </div>
                            <div class="col-md-6 mb-3">
                                <label class="form-label">Stok Tersedia</label>
                                <input type="text" class="form-control" id="modal_produk_stok" readonly>
                            </div>
                        </div>
                        <div class="mb-3">
                            <label for="jumlah" class="form-label">Jumlah</label>
                            <input type="number" class="form-control" id="jumlah" name="jumlah" value="1" min="1" required>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Batal</button>
                        <button type="submit" name="tambah_produk" class="btn btn-primary">Tambah ke Keranjang</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        // Inisialisasi modal produk
        var produkModal = document.getElementById('produkModal');
        produkModal.addEventListener('show.bs.modal', function(event) {
            var button = event.relatedTarget;
            var id = button.getAttribute('data-id');
            var nama = button.getAttribute('data-nama');
            var harga = button.getAttribute('data-harga');
            var stok = button.getAttribute('data-stok');

            document.getElementById('modal_produk_id').value = id;
            document.getElementById('modal_produk_nama').value = nama;
            document.getElementById('modal_produk_harga').value = 'Rp ' + parseInt(harga).toLocaleString('id-ID');
            document.getElementById('modal_produk_stok').value = stok;
            document.getElementById('jumlah').setAttribute('max', stok);
            document.getElementById('jumlah').value = 1;
        });

        // Hitung kembalian
        document.getElementById('bayar')?.addEventListener('input', function() {
            var bayar = parseInt(this.value) || 0;
            var total = <?= $total ?>;
            var kembali = bayar - total;

            document.getElementById('kembali').value = kembali >= 0 ? kembali.toLocaleString('id-ID') : '0';
        });
    </script>
</body>
</html>